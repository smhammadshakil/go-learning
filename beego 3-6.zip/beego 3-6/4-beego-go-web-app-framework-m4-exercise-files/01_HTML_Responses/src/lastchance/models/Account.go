package models

type Account struct {
	ID     int
	Name   string
	Number string
	Amount float64
}
